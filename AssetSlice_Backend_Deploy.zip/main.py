from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from pydantic import BaseModel
from typing import Dict
from jinja2 import Template
import tempfile

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

class PropertyData(BaseModel):
    address: str
    purchase_price: float
    land_value: float
    acquisition_date: str
    property_type: str

@app.post("/api/cost-seg-report")
def generate_cost_seg_report(data: PropertyData):
    building_basis = data.purchase_price - data.land_value
    allocations = {
        "5_year": round(building_basis * 0.20, 2),
        "15_year": round(building_basis * 0.10, 2),
        "27_5_or_39_year": round(building_basis * 0.70, 2),
    }
    schedule = {
        "Year 1": round(allocations["5_year"] / 5 + allocations["15_year"] / 15 + allocations["27_5_or_39_year"] / 39, 2),
        "Year 2": round(allocations["5_year"] / 5 + allocations["15_year"] / 15 + allocations["27_5_or_39_year"] / 39, 2),
    }
    return {
        "address": data.address,
        "purchase_price": data.purchase_price,
        "building_basis": building_basis,
        "allocations": allocations,
        "depreciation_schedule": schedule,
    }

@app.post("/api/cost-seg-report-pdf")
def generate_pdf(data: PropertyData):
    building_basis = data.purchase_price - data.land_value
    allocations = {
        "5_year": round(building_basis * 0.20, 2),
        "15_year": round(building_basis * 0.10, 2),
        "27_5_or_39_year": round(building_basis * 0.70, 2),
    }
    schedule = {
        "Year 1": round(allocations["5_year"] / 5 + allocations["15_year"] / 15 + allocations["27_5_or_39_year"] / 39, 2),
        "Year 2": round(allocations["5_year"] / 5 + allocations["15_year"] / 15 + allocations["27_5_or_39_year"] / 39, 2),
    }

    html_template = Template("""
    <html><body>
      <h2>Cost Segregation Report</h2>
      <p><strong>Property:</strong> {{ address }}</p>
      <p><strong>Building Basis:</strong> ${{ building_basis }}</p>
      <h3>Allocations:</h3>
      <ul>
        <li>5-Year: ${{ allocations['5_year'] }}</li>
        <li>15-Year: ${{ allocations['15_year'] }}</li>
        <li>27.5/39-Year: ${{ allocations['27_5_or_39_year'] }}</li>
      </ul>
      <h3>Depreciation Schedule:</h3>
      <ul>
        {% for year, amount in schedule.items() %}
          <li>{{ year }}: ${{ amount }}</li>
        {% endfor %}
      </ul>
    </body></html>
    """)
    rendered_html = html_template.render(
        address=data.address,
        building_basis=building_basis,
        allocations=allocations,
        schedule=schedule
    )

    with tempfile.NamedTemporaryFile(delete=False, suffix=".pdf") as tmpfile:
        from weasyprint import HTML
        HTML(string=rendered_html).write_pdf(tmpfile.name)
        return FileResponse(tmpfile.name, filename="Cost_Seg_Report.pdf", media_type='application/pdf')
